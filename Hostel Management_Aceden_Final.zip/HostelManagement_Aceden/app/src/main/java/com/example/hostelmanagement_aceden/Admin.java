package com.example.hostelmanagement_aceden;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Admin extends AppCompatActivity {
    Button _btnLogOutAd,_btnLtAtt,_btnLtSt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        _btnLogOutAd = (Button) findViewById(R.id.btnLogOutAd);
        _btnLtAtt = (Button) findViewById(R.id.btnLtAtt);
        _btnLtSt = (Button) findViewById(R.id.btnLtSt);
        _btnLogOutAd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Admin.this,MainActivity.class);
                startActivity(intent);
            }
        });
        _btnLtAtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Admin.this,ViewAttendanceWarden.class);
                startActivity(intent);
            }
        });
        _btnLtSt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Admin.this,ListOfStudents.class);
                startActivity(intent);
            }
        });
    }
}