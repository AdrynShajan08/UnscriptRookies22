package com.example.hostelmanagement_aceden;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

public class Attendance extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        TextView attenForm = (TextView) findViewById(R.id.linkAttenForm);
        attenForm.setMovementMethod(LinkMovementMethod.getInstance());
    }
}