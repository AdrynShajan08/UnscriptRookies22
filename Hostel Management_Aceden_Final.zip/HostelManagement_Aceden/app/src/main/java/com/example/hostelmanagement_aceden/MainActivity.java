package com.example.hostelmanagement_aceden;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

public class MainActivity extends AppCompatActivity {


    EditText _txtEmail,_txtPass;
    Button _btnLogin,_btnUnReg;
    Spinner _spinner;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        _txtPass = (EditText) findViewById(R.id.txtPass);
        _txtEmail = (EditText) findViewById(R.id.txtEmail);
        _btnLogin = (Button) findViewById(R.id.btnLogin);
        _spinner = (Spinner) findViewById(R.id.spinner);
        _btnUnReg = (Button) findViewById(R.id.btnUnReg);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        userID = fAuth.getCurrentUser().getUid();
        DocumentReference documentReference = fStore.collection("user").document(userID);



        ArrayAdapter <CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.usertype,R.layout.support_simple_spinner_dropdown_item);
        _spinner.setAdapter(adapter);

        _btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = _spinner.getSelectedItem().toString();
                if(_txtEmail.getText().toString().equals("STUDENT@gmail.com") && _txtPass.getText().toString().equals("STUDENT") && item.equals("Student"))
                {
                    Intent intent = new Intent(MainActivity.this,Student.class);
                    startActivity(intent);
                }
                else if(_txtEmail.getText().toString().equals("ADMIN1@gmail.com") && _txtPass.getText().toString().equals("ADMIN1") && item.equals("Admin"))
                {
                    Intent intent = new Intent(MainActivity.this,Admin.class);
                    startActivity(intent);
                }
                else if(_txtEmail.getText().toString().equals("WARDEN1@gmail.com") && _txtPass.getText().toString().equals("WARDEN1") && item.equals("Warden"))
                {
                    Intent intent = new Intent(MainActivity.this,Warden.class);
                    startActivity(intent);
                }

                String email = _txtEmail.getText().toString().trim();
                String password = _txtPass.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    _txtEmail.setError("Email is required.");
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    _txtPass.setError("Password is required.");
                    return;
                }

                if (password.length() < 6) {
                    _txtPass.setError("Password must be greater than 6 .");
                    return;
                }

                fAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful() && item.equals("Student")) {
                            Toast.makeText(MainActivity.this, "Logged in Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), Student.class));
                        }
                        else {
                            Toast.makeText(MainActivity.this, "Error" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        _btnUnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),signUp.class));
            }
        });

    }
}