package com.example.hostelmanagement_aceden;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Student extends AppCompatActivity {
     Button _btnLogOutSd,_btnAdAtt,_btnSett,_btnFeedBck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        _btnLogOutSd = (Button) findViewById(R.id.btnLogOutSd);
        _btnAdAtt = (Button) findViewById(R.id.btnAdAtt);
        _btnSett= (Button) findViewById(R.id.btnSett);
        _btnFeedBck=(Button) findViewById(R.id.btnFeedBck);
        _btnLogOutSd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Student.this,MainActivity.class);
                startActivity(intent);
            }
        });
        _btnAdAtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Student.this,Attendance.class);
                startActivity(intent);
            }
        });
        _btnSett.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Student.this,StudentSettings.class);
                startActivity(intent);
            }
        });
        _btnFeedBck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Student.this,FeedBack.class);
                startActivity(intent);
            }
        });

    }
}