package com.example.hostelmanagement_aceden;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class StudentSettings extends AppCompatActivity {
    Spinner _LocSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_settings);
        _LocSpinner = (Spinner) findViewById(R.id.locSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.location,R.layout.support_simple_spinner_dropdown_item);
        _LocSpinner.setAdapter(adapter);
    }
}