package com.example.hostelmanagement_aceden;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

public class ViewAttendanceWarden extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendance_warden);
        TextView attenForm = (TextView) findViewById(R.id.linkViewAttenForm);
        attenForm.setMovementMethod(LinkMovementMethod.getInstance());
    }
}