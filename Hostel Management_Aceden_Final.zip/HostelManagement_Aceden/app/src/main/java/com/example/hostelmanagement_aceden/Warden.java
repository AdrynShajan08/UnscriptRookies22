package com.example.hostelmanagement_aceden;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Warden extends AppCompatActivity {
    Button _btnLogOutWd,_btnVwAtt,_btnAddNewSt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warden);
        _btnLogOutWd = (Button) findViewById(R.id.btnLogOutWd);
        _btnVwAtt = (Button) findViewById(R.id.btnVwAtt);
        _btnAddNewSt = (Button) findViewById(R.id.btnAddNewSt);
        _btnLogOutWd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Warden.this,MainActivity.class);
                startActivity(intent);
            }
        });
        _btnVwAtt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Warden.this,ViewAttendanceWarden.class);
                startActivity(intent);
            }
        });
        _btnAddNewSt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Warden.this,WardenAddNewStudent.class);
                startActivity(intent);
            }
        });
    }
}