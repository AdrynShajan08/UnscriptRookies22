package com.example.hostelmanagement_aceden;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class WardenAddNewStudent extends AppCompatActivity {

    FirebaseAuth fAuth;
    EditText _txtName,_txtEmail,_txtPass,_txtPhone;
    Button _btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warden_add_new_student);
        _txtName = (EditText) findViewById(R.id.txtName) ;
        _txtEmail = (EditText) findViewById(R.id.txtEmail) ;
        _txtPass = (EditText) findViewById(R.id.txtPass) ;
        _txtPhone = (EditText) findViewById(R.id.txtPhone) ;
        _btnSave = (Button) findViewById(R.id.btnSave);    //to save details
        fAuth = FirebaseAuth.getInstance();

         /*if(fAuth.getCurrentUser()!= null){
             startActivity(new Intent(getApplicationContext(),MainActivity.class));
             finish();
         }*/

        _btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = _txtEmail.getText().toString().trim();
                String password = _txtPass.getText().toString().trim();

                if(TextUtils.isEmpty(email)){
                    _txtEmail.setError("Email is required.");
                    return;
                }

                if(TextUtils.isEmpty(password)){
                    _txtPass.setError("Password is required.");
                    return;
                }

                if(password.length()<6){
                    _txtPass.setError("Password must be greater than 6 .");
                    return;
                }

                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(WardenAddNewStudent.this, "User created.", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        }
                        else
                        {
                            Toast.makeText(WardenAddNewStudent.this, "Error"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

    }
}