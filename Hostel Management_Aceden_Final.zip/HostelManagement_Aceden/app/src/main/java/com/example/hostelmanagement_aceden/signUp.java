package com.example.hostelmanagement_aceden;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class signUp extends AppCompatActivity {
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    EditText _txtName,_txtEmail,_txtPass,_txtPhone;
    Button _btnAlReg,_btnSave;
    Spinner _LocSpinner,_spinner;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        _txtName = (EditText) findViewById(R.id.txtName) ;
        _txtEmail = (EditText) findViewById(R.id.txtEmail) ;
        _txtPass = (EditText) findViewById(R.id.txtPass) ;
        _txtPhone = (EditText) findViewById(R.id.txtPhone) ;
        _btnAlReg = (Button) findViewById(R.id.btnAlReg);  //for already signed in
        _btnSave = (Button) findViewById(R.id.btnSave);    //to save details
        _spinner = (Spinner) findViewById(R.id.spinner);
        _LocSpinner = (Spinner) findViewById(R.id.locSpinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.location,R.layout.support_simple_spinner_dropdown_item);
        _LocSpinner.setAdapter(adapter);
        ArrayAdapter <CharSequence> adapter1 = ArrayAdapter.createFromResource(this,R.array.usertype,R.layout.support_simple_spinner_dropdown_item);
        _spinner.setAdapter(adapter1);

         fAuth = FirebaseAuth.getInstance();
         fStore = FirebaseFirestore.getInstance();

         /*if(fAuth.getCurrentUser()!= null){
             startActivity(new Intent(getApplicationContext(),MainActivity.class));
             finish();
         }*/

         _btnSave.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 String email = _txtEmail.getText().toString().trim();
                 String password = _txtPass.getText().toString().trim();
                 String name = _txtName.getText().toString().trim();
                 String phone = _txtPhone.getText().toString().trim();
                 String location = _LocSpinner.getSelectedItem().toString();
                 String userType = _spinner.getSelectedItem().toString();


                 if(TextUtils.isEmpty(email)){
                     _txtEmail.setError("Email is required.");
                     return;
                 }

                 if(TextUtils.isEmpty(password)){
                     _txtPass.setError("Password is required.");
                     return;
                 }

                 if(password.length()<6){
                     _txtPass.setError("Password must be greater than 6 .");
                     return;
                 }

                 fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                     @Override
                     public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(signUp.this, "User created.", Toast.LENGTH_SHORT).show();
                            userID = fAuth.getCurrentUser().getUid();
                            DocumentReference documentReference = fStore.collection("user").document(userID);
                            Map<String,Object> user = new HashMap<>();
                            user.put("fname",name);
                            user.put("email",email);
                            user.put("phone",phone);
                            user.put("location",location);
                            user.put("userType",userType);
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Log.d("TAG","onSuccess:User profile is created for"+userID);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.d("TAG","onFailure: "+e.toString());
                                }
                            });

                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        }
                        else
                        {
                            Toast.makeText(signUp.this, "Error"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                     }
                 });
             }
         });
        _btnAlReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(signUp.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}